/* ============================================================================
 * AMES Wholesale Power Market Test Bed (Java): A Free Open-Source Test-Bed  
 *         for the Agent-based Modeling of Electricity Systems 
 * ============================================================================
 *
 * (C) Copyright 2008, by Hongyan Li, Junjie Sun, and Leigh Tesfatsion
 *
 *    Homepage: http://www.econ.iastate.edu/tesfatsi/AMESMarketHome.htm
 *
 * LICENSING TERMS
 * The AMES Market Package is licensed by the copyright holders (Junjie Sun, 
 * Hongyan Li, and Leigh Tesfatsion) as free open-source software under the       
 * terms of the GNU General Public License (GPL). Anyone who is interested is 
 * allowed to view, modify, and/or improve upon the code used to produce this 
 * package, but any software generated using all or part of this code must be 
 * released as free open-source software in turn. The GNU GPL can be viewed in 
 * its entirety as in the following site: http://www.gnu.org/licenses/gpl.html
 */

// RTMarket.java
// Real-time market

package amesmarket;
import java.util.ArrayList;
import org.apache.commons.vfs2.*;
import org.apache.commons.vfs2.impl.DefaultFileMonitor;

public class RTMarket {

  //Real time market's data
  private AMESMarket ames;
  private ISO iso;
  
  private double[][] supplyOfferByGen;
  private double[][] priceSensitiveDispatch;
  

  private int numGenAgents;
  private int numLSEAgents;
  private int numSupplyOfferParams;
  private int numHoursPerDay;

  // constructor
  public RTMarket(ISO independentSystemOperator,AMESMarket model){

    //System.out.println("Created a RTMarket objecct");
    ames = model;
    iso=independentSystemOperator;
    numGenAgents = ames.getNumGenAgents();
    numLSEAgents = ames.getNumLSEAgents();
    numHoursPerDay = ames.getNumHoursPerDay();
    numSupplyOfferParams = 4;

    supplyOfferByGen = new double[numGenAgents][numSupplyOfferParams];
    
    priceSensitiveDispatch = new double[numHoursPerDay][numLSEAgents];
    
  }
  public void realTimeOperation(int h, int d){

    System.out.println("Hour " + h + " Day " + d +": Real Time Market operation.");
    supplyOfferByGen=iso.getSupplyOfferByGenRT();
    priceSensitiveDispatch=iso.getPriceSensitiveDispatchRT();


    }
 
  public double[][] getSupplyOfferByGen(){
    return supplyOfferByGen;
  }

  public double[][] getPriceSensitiveDispatch(){
    return priceSensitiveDispatch;
  }
  
}
